# Review Before Upload

Buyer must run the steps on their own device, keep the original file, and review the output before uploading it to the destination site.
This is a troubleshooting plan only. It does not guarantee portal, school, employer, marketplace, email, or government acceptance.

- Confirm the file opens on your device.
- Confirm the file size, dimensions, and format match the destination rule.
- Confirm names, dates, faces, signatures, text, and important details remain readable.
- Confirm you are uploading the intended new copy, not the original or a failed draft.
- If the destination still rejects it, copy the public-safe error text and compare it with the target rule again.
