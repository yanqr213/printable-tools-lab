# Sample Upload Limit Case - Upload Limit Fix Plan

Upload error: PDF must be less than 1 MB
File type: PDF resume
Target rule: PDF under 1MB, PDF format required
Use case: job application portal
Needed by: 2026-06-10

## Included files

- recommended-tool.md
- target-settings.md
- fallback-steps.md
- review-before-upload.md
- service-order-status.json

Buyer must run the steps on their own device, keep the original file, and review the output before uploading it to the destination site.
This is a troubleshooting plan only. It does not guarantee portal, school, employer, marketplace, email, or government acceptance.

This public sample is not revenue. Real revenue is counted only after an external provider shows a paid order, payout balance, or settled payment.
