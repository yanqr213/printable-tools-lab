# Fallback Steps

1. Use the closest PDF target named by the portal.
2. If the output is still too large, try a stricter target once and compare readability.
3. For scanned PDFs, compress the source images or split pages before rebuilding the final PDF.

Stop if the final file becomes unreadable. Keep the original file and make a fresh copy before trying stronger compression.
