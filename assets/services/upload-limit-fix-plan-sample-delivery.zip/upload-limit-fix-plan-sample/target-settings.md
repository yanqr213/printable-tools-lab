# Target Settings

Portal rule: PDF under 1MB, PDF format required
Suggested first target: 1MB PDF target
Output format: PDF

Prior attempts noted: Tried one lower quality export; still too large

Use the exact target from the destination site when it is available. If the output is still rejected, use the fallback steps before changing the source document.
