# Sample Freelance Studio - Invoice Follow-up Copy Pack

Invoice status: sent, due soon
Preferred tone: friendly, concise, professional
Needed by: 2026-06-10

## Included files

- polite-payment-reminder.md
- due-today-note.md
- first-overdue-follow-up.md
- paid-thank-you.md
- next-invoice-note.md
- review-before-sending.md
- service-order-status.json

Buyer must review every message for accuracy, tone, client relationship, and applicable local rules before sending.
This is editable communication copy only, not legal, tax, accounting, debt-collection, or financial advice.

This public sample is not revenue. Real revenue is counted only after an external provider shows a paid order, payout balance, or settled payment.
