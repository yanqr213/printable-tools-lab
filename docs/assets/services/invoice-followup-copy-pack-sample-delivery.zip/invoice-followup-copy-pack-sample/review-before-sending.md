# Review Before Sending

Buyer must review every message for accuracy, tone, client relationship, and applicable local rules before sending.
This is editable communication copy only, not legal, tax, accounting, debt-collection, or financial advice.

- Replace placeholders before sending.
- Confirm payment wording matches the invoice and does not expose private account details.
- Remove any late-fee, legal, or collection language that was not already agreed and reviewed by the buyer.
- Do not include private invoice numbers, client private data, bank details, tax IDs, or account credentials.

## Buyer-requested avoid list
- legal threats
- late-fee language not already agreed
- tax or accounting advice
