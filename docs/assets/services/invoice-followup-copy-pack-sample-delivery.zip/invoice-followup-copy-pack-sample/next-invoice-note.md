Subject: Next invoice / recurring work note

Hi [Client name],

Thanks again for the recent work together. For the next invoice or recurring work cycle, I will keep the scope, timing, and payment details clear before starting.

Please let me know if anything needs to change for the next round.

[Sample Freelance Studio]
