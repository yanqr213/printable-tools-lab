Subject: Follow-up on overdue invoice from Sample Freelance Studio

Hi [Client name],

I am following up because the invoice for [project/service] now appears overdue on my side.

Pay through the secure link already shared on the invoice If payment has already been sent, please disregard this note or let me know so I can update my records.

Thanks,
[Sample Freelance Studio]
