Subject: Invoice due today - Sample Freelance Studio

Hi [Client name],

Just a quick note that the invoice for [project/service] is due today. Pay through the secure link already shared on the invoice

Thank you for taking care of it.

[Sample Freelance Studio]
