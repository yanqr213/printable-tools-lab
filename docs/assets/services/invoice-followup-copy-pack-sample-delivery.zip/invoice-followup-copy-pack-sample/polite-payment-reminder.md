Subject: Friendly reminder: invoice from Sample Freelance Studio

Hi [Client name],

I hope you are doing well. I wanted to send a quick reminder about the invoice for [project/service]. Pay through the secure link already shared on the invoice

Please let me know if you need anything else from me to process it.

Thanks,
[Sample Freelance Studio]
