Subject: Payment received - thank you

Hi [Client name],

Thank you, I received the payment for [project/service]. I appreciate it.

I look forward to working with you again.

[Sample Freelance Studio]
