# Sample Market Table

## Simple flyer headline
Sample Market Table: handmade soaps, candles, and small gift bundles for Saturday craft market

## Short intro
Sample Market Table is preparing a simple clean, friendly, practical table setup with clear prices, easy contact details, and a small starter offer for shoppers who want to take action today.

## Feature bullets
- Lavender soap bar: $6 (Two for $10)
- Mini soy candle: $9 (Best seller)
- Gift bundle: $18 (Includes soap and candle)

## Call to action
Scan or contact @samplemarkettable to ask what is available today.

## Print reminder
Buyer must review all copy, prices, QR targets, dates, claims, and local compliance before printing or publishing.
