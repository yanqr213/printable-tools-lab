# Review Before Printing

Buyer must review all copy, prices, QR targets, dates, claims, and local compliance before printing or publishing.

Do not treat this pack as legal, tax, accounting, medical, food-labeling, advertising-compliance, or financial advice.
Remove any claim that the seller cannot verify or legally use.
If the buyer sells regulated goods or services, they must adapt this starter copy with qualified local guidance.

## Buyer-requested avoid list
- medical, skincare, or guaranteed result claims
- discount promises not approved by the seller
