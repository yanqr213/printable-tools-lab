# QR Sign Copy

Headline: Scan for Sample Market Table
Subline: Prices, pickup details, or current availability
QR target to test before printing: https://example.com/sample-order-page
Backup contact text: @samplemarkettable

Small-print reminder: Please confirm the QR opens the intended public page or contact method before printing.
