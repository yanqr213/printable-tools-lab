# One-page Launch Checklist

- Review every price and SKU.
- Test the QR code on a phone that is not already logged into the seller account.
- Print one draft page before printing a full batch.
- Place price tags beside the matching products or service rows.
- Keep one flyer near checkout or the front of the table.
- Keep coupon language simple and honor only offers the seller approves.
- Save the final CSV and Markdown files for the next market or pickup window.
- Track which sign or offer produces replies, scans, or sales.
- Update stale prices before the next event.
- Ask for one lightweight revision only if the change is within the original $29 scope.
