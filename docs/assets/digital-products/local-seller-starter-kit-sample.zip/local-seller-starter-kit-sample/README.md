# Local Seller Starter Kit Sample

A checkout-ready digital pack of editable local-selling templates: price tags, coupon copy, packing slips, QR sign wording, inventory starters, promo posts, and market-day checklists.

## How to use

1. Open the CSV files in any spreadsheet app.
2. Edit the placeholder business, product, offer, and date fields.
3. Paste rows into the matching PrintableTools Lab generators for price tags, coupons, flyers, QR signs, packing slips, inventory sheets, and business cards.
4. Print a small batch, test it at the table or with one customer, then adjust wording before printing more.

This sample shows the structure of the paid kit. The paid ZIP adds the full 30-day calendar, more rows, more copy variants, and the commercial-use license.
